# arduino-MLX90393
Arduino library for MLX90393 magnetometer sensor
